<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="decor_3" tilewidth="38" tileheight="35" tilecount="9" columns="3">
 <image source="Sand/decor_3.png" width="114" height="115"/>
</tileset>
