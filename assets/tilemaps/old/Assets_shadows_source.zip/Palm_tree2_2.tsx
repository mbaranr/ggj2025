<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Palm_tree2_2" tilewidth="32" tileheight="30" tilecount="4" columns="2">
 <image source="Sand/Palm_tree2_2.png" width="64" height="64"/>
</tileset>
