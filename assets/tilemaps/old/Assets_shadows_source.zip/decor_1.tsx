<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="decor_1" tilewidth="50" tileheight="48" margin="2" tilecount="42" columns="7">
 <image source="Sand/decor_1.png" width="356" height="296"/>
</tileset>
