<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Water" tilewidth="32" tileheight="33" tilecount="6" columns="3">
 <image source="Water+related/Water.png" width="96" height="96"/>
</tileset>
