<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="the-evening-gale-3-level-frigate-sailing-vessel-with-png-v0-sssi5wrxvcva1" tilewidth="30" tileheight="28" tilecount="1911" columns="21">
 <image source="../../../Downloads/the-evening-gale-3-level-frigate-sailing-vessel-with-png-v0-sssi5wrxvcva1.webp" width="640" height="2560"/>
</tileset>
