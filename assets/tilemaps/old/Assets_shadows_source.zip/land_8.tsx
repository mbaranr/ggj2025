<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="land_8" tilewidth="32" tileheight="30" margin="2" tilecount="56" columns="7">
 <image source="Sand/land_8.png" width="256" height="256"/>
</tileset>
