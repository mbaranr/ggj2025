<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="tree_5" tilewidth="32" tileheight="30" tilecount="40" columns="5">
 <image source="Sand/tree_5.png" width="187" height="244"/>
</tileset>
