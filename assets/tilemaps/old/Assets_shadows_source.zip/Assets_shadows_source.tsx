<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Assets_shadows_source" tilewidth="32" tileheight="30" tilecount="210" columns="15">
 <image source="Sand/Assets_shadows_source.png" width="496" height="432"/>
</tileset>
