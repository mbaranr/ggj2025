<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Forest Props" tilewidth="32" tileheight="30" tilecount="285" columns="15">
 <image source="../../../Downloads/Forest Props.png" width="480" height="592"/>
</tileset>
