<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="building_2" tilewidth="32" tileheight="30" tilecount="240" columns="20">
 <image source="Sand/building_2.png" width="650" height="378"/>
</tileset>
