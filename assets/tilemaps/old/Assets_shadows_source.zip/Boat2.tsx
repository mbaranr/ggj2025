<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Boat2" tilewidth="29" tileheight="27" tilecount="2" columns="1">
 <image source="Water+related/Boat2.png" width="31" height="73"/>
</tileset>
