<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Water Tileset" tilewidth="28" tileheight="26" tilecount="36" columns="6">
 <image source="../../../Downloads/Water Tileset.png" width="176" height="160"/>
</tileset>
