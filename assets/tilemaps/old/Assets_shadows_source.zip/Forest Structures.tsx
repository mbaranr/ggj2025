<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Forest Structures" tilewidth="29" tileheight="30" tilecount="154" columns="14">
 <image source="../../../Downloads/Forest Structures.png" width="416" height="352"/>
</tileset>
