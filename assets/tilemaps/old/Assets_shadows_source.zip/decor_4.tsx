<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="decor_4" tilewidth="36" tileheight="34" tilecount="6" columns="6">
 <image source="Sand/decor_4.png" width="217" height="57"/>
</tileset>
