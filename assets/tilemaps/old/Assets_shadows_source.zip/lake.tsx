<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="lake" tilewidth="32" tileheight="33" tilecount="102" columns="17">
 <image source="Sand/lake.png" width="559" height="221"/>
</tileset>
