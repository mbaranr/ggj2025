<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="the-evening-gale-3-level-frigate-sailing-vessel-with-png-v0-c5weddptvcva1" tilewidth="34" tileheight="32" tilecount="252" columns="18">
 <image source="../../../Downloads/the-evening-gale-3-level-frigate-sailing-vessel-with-png-v0-c5weddptvcva1.webp" width="640" height="465"/>
</tileset>
