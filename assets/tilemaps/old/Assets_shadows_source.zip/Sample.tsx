<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Sample" tilewidth="32" tileheight="30" tilecount="240" columns="15">
 <image source="../../../Downloads/Sample.png" width="500" height="500"/>
</tileset>
