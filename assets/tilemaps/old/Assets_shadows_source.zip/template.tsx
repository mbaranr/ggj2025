<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="template" tilewidth="32" tileheight="30" tilecount="4352" columns="64">
 <image source="../../../Downloads/Map.webp" width="2048" height="2048"/>
</tileset>
