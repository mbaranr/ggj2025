<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="road_18" tilewidth="32" tileheight="34" tilecount="2" columns="2">
 <image source="Sand/road_18.png" width="64" height="64"/>
</tileset>
