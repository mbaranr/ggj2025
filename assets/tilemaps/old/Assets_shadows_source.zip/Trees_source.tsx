<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Trees_source" tilewidth="32" tileheight="45" tilecount="100" columns="25">
 <image source="Sand/Trees_source.png" width="800" height="192"/>
</tileset>
